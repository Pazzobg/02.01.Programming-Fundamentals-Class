﻿using System.Collections.Generic;

namespace _06.BookLibraryModification
{
    public class Library
    {
        public string Name { get; set; }

        public List<Book> BooksList { get; set; }
    }
}
